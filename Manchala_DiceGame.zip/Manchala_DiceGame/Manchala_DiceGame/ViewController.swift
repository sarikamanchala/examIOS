//
//  ViewController.swift
//  Manchala_DiceGame
//
//  Created by Manchala,Sarika on 4/7/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var player1: UITextField!
    
    @IBOutlet weak var player2: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func playButton(_ sender: UIButton) {
       
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
              if transition == "gameSegue"{
                  var destination = segue.destination as! GameViewController
                  destination.play1 = player1.text!
                  destination.play2 = player2.text!
    }
    }
}

