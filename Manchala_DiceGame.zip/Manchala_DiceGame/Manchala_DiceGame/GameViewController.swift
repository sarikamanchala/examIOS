//
//  GameViewController.swift
//  Manchala_DiceGame
//
//  Created by Manchala,Sarika on 4/7/22.
//

import UIKit

class GameViewController: UIViewController {

    
    @IBOutlet weak var label1: UILabel!
    
    @IBOutlet weak var label2: UILabel!
    
    @IBOutlet weak var rollButton: UIButton!
    
    @IBOutlet weak var label3: UILabel!
    
    @IBOutlet weak var label4: UILabel!
    
    @IBOutlet weak var resultImage: UIImageView!
    var play1 = ""
    var play2 = ""
    var count1 : Int = 0
    var count2 : Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        label1.text = label1.text!+"Total number of games \(play1) won: \(count1)"
        label2.text = label2.text!+"Total number of games \(play2) won: \(count2)"
        label3.text = label3.text!+"\(play1) current score : nil"
        label4.text = label4.text!+"\(play2) current score : nil"
        resultImage.image =  UIImage(named: "play")
        // Do any additional setup after loading the view.
    }
    
    @IBAction func rollButton(_ sender: UIButton) {
        let rand1 = Int.random(in: 1..<7)
        let rand2 = Int.random(in: 1..<7)
        if(rand1>rand2)
        {
            count1 = count1+1;
            resultImage.image = UIImage(named: "dice\(rand1)")
            label1.text = "Total number of games \(play1) won: \(count1)"
            label2.text = "Total number of games \(play2) won: \(count2)"
            label3.text = "\(play1) current score : \(rand1)"
            label4.text = "\(play2) current score : \(rand2)"
        }
        else if(rand2>rand1)
        {
            resultImage.image = UIImage(named: "dice\(rand2)")
            count2 = count2+1;
            label1.text = "Total number of games \(play1) won: \(count1)"
            label2.text = "Total number of games \(play2) won: \(count2)"
            label3.text = "\(play1) current score : \(rand1)"
            label4.text = "\(play2) current score : \(rand2)"
        }
        else
        {
            resultImage.image = UIImage(named: "tie")
            label1.text = "Total number of games \(play1) won: \(count1)"
            label2.text = "Total number of games \(play2) won: \(count2)"
            label3.text = "\(play1) current score : \(rand1)"
            label4.text = "\(play2) current score : \(rand2)"
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
